﻿$(function () {
    var l = abp.localization.getResource('BookStore');

    var dataTable = $('#AuthorsTable').DataTable(
        abp.libs.datatables.normalizeConfiguration({
            serverSide: true,
            paging: true,
            order: [[1, "asc"]],
            searching: false,
            scrollX: true,
            ajax: abp.libs.datatables.createAjax(acme.bookStore.authors.author.getFavouriteList),
            columnDefs: [
                {
                    title: l('Actions'),
                    rowAction: {
                        items:
                            [
                                {
                                    text: l('Remove'),
                                    visible: abp.auth.isGranted('BookStore.Authors.Liked'), //CHECK for the PERMISSION
                                    action: function (data) {
                                        acme.bookStore.authors.author.dislike(data.record.id)
                                            .then(function () {
                                                abp.notify.info(l('SuccessfullyDisliked'));
                                                dataTable.ajax.reload();
                                            });
                                    }

                                }
                            ]
                    }
                },
                {
                    title: l('Name'),
                    data: "name"
                },
                {
                    title: l('BirthDate'),
                    data: "birthDate",
                    render: function (data) {
                        return luxon
                            .DateTime
                            .fromISO(data, {
                                locale: abp.localization.currentCulture.name
                            }).toLocaleString();
                    }
                }
            ]
        })
    );
});
