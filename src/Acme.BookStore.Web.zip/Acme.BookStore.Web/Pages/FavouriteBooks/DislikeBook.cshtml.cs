using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Acme.BookStore.Books;
using Acme.BookStore.Web.Pages.Books;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Acme.BookStore.Web.Pages.FavouriteBooks
{
    public class DislikeBookModel : LikeBookModel
    {
        private readonly LikeBookModel _likeBookModel = new LikeBookModel();
        public async Task OnGet()
        {
            await _likeBookModel.OnGetAsync(_likeBookModel.Book.Id);
        }
        public async Task<IActionResult> OnPost()
        {
            await _likeBookModel.OnPostAsync();
            return NoContent();
        }
    }
    

}
